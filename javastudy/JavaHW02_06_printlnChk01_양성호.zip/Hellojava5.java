
class HelloJava5{
	public static void main (String args []){
		java.lang.System.out.print("HelloJava5");
		java.lang.System.out.print("HelloJava5");
		java.lang.System.out.print("HelloJava5");
	}
}