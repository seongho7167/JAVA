
class HelloJava6{
	public static void main (String args []){
		java.lang.System.out.println("HelloJava5");
		java.lang.System.out.println("HelloJava5");
		java.lang.System.out.println("HelloJava5");
	}
}